﻿namespace CarServiceShop
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txtBoxFirstName = new System.Windows.Forms.TextBox();
            this.txtBoxModel = new System.Windows.Forms.TextBox();
            this.txtBoxColour = new System.Windows.Forms.TextBox();
            this.txtBoxPhone = new System.Windows.Forms.TextBox();
            this.txtBoxLastName = new System.Windows.Forms.TextBox();
            this.comboBoxMake = new System.Windows.Forms.ComboBox();
            this.txtBoxCost = new System.Windows.Forms.TextBox();
            this.Check_Box_Engine = new System.Windows.Forms.CheckBox();
            this.checkBoxFilter = new System.Windows.Forms.CheckBox();
            this.checkBoxTransmission = new System.Windows.Forms.CheckBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnNew = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnRemove = new System.Windows.Forms.Button();
            this.btnRemoveAll = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.listView1 = new System.Windows.Forms.ListView();
            this.ColNum = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ColFirstName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ColLastName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ColPhone = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ColMake = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ColModel = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ColYear = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ColColour = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ColEngine = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ColTransmission = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ColFilter = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ColCost = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.comboBoxYear = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(58, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(106, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Customer Information";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(58, 59);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "First Name:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(58, 86);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Last Name:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(58, 110);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Phone:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(58, 160);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(78, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Car Information";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(58, 191);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(37, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Make:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(58, 219);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(39, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "Model:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(58, 244);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(32, 13);
            this.label8.TabIndex = 7;
            this.label8.Text = "Year:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(58, 271);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(40, 13);
            this.label9.TabIndex = 8;
            this.label9.Text = "Colour:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(58, 296);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(51, 13);
            this.label10.TabIndex = 9;
            this.label10.Text = "Services:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(58, 377);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(31, 13);
            this.label11.TabIndex = 10;
            this.label11.Text = "Cost:";
            // 
            // txtBoxFirstName
            // 
            this.txtBoxFirstName.Location = new System.Drawing.Point(140, 56);
            this.txtBoxFirstName.Name = "txtBoxFirstName";
            this.txtBoxFirstName.Size = new System.Drawing.Size(121, 20);
            this.txtBoxFirstName.TabIndex = 0;
            this.toolTip1.SetToolTip(this.txtBoxFirstName, "Enter your First Name");
            // 
            // txtBoxModel
            // 
            this.txtBoxModel.Location = new System.Drawing.Point(140, 216);
            this.txtBoxModel.Name = "txtBoxModel";
            this.txtBoxModel.Size = new System.Drawing.Size(121, 20);
            this.txtBoxModel.TabIndex = 4;
            this.toolTip1.SetToolTip(this.txtBoxModel, "Enter the Model of your Vehicle");
            // 
            // txtBoxColour
            // 
            this.txtBoxColour.Location = new System.Drawing.Point(140, 268);
            this.txtBoxColour.Name = "txtBoxColour";
            this.txtBoxColour.Size = new System.Drawing.Size(121, 20);
            this.txtBoxColour.TabIndex = 6;
            this.toolTip1.SetToolTip(this.txtBoxColour, "Enter the colour of your vehicle");
            // 
            // txtBoxPhone
            // 
            this.txtBoxPhone.Location = new System.Drawing.Point(140, 107);
            this.txtBoxPhone.Name = "txtBoxPhone";
            this.txtBoxPhone.Size = new System.Drawing.Size(121, 20);
            this.txtBoxPhone.TabIndex = 2;
            this.toolTip1.SetToolTip(this.txtBoxPhone, "Enter your Numeric Phone Number");
            // 
            // txtBoxLastName
            // 
            this.txtBoxLastName.Location = new System.Drawing.Point(140, 83);
            this.txtBoxLastName.Name = "txtBoxLastName";
            this.txtBoxLastName.Size = new System.Drawing.Size(121, 20);
            this.txtBoxLastName.TabIndex = 1;
            this.toolTip1.SetToolTip(this.txtBoxLastName, "Enter Your Last Name");
            // 
            // comboBoxMake
            // 
            this.comboBoxMake.FormattingEnabled = true;
            this.comboBoxMake.Location = new System.Drawing.Point(140, 188);
            this.comboBoxMake.Name = "comboBoxMake";
            this.comboBoxMake.Size = new System.Drawing.Size(121, 21);
            this.comboBoxMake.TabIndex = 3;
            this.toolTip1.SetToolTip(this.comboBoxMake, "Select The Type of Car");
            // 
            // txtBoxCost
            // 
            this.txtBoxCost.Location = new System.Drawing.Point(140, 374);
            this.txtBoxCost.Name = "txtBoxCost";
            this.txtBoxCost.ReadOnly = true;
            this.txtBoxCost.Size = new System.Drawing.Size(121, 20);
            this.txtBoxCost.TabIndex = 18;
            this.toolTip1.SetToolTip(this.txtBoxCost, "Displays the price of the services");
            // 
            // Check_Box_Engine
            // 
            this.Check_Box_Engine.AutoSize = true;
            this.Check_Box_Engine.Location = new System.Drawing.Point(140, 305);
            this.Check_Box_Engine.Name = "Check_Box_Engine";
            this.Check_Box_Engine.Size = new System.Drawing.Size(114, 17);
            this.Check_Box_Engine.TabIndex = 7;
            this.Check_Box_Engine.Text = "Engine Oil Change";
            this.toolTip1.SetToolTip(this.Check_Box_Engine, "Select if your car had an engine oil change");
            this.Check_Box_Engine.UseVisualStyleBackColor = true;
            this.Check_Box_Engine.CheckedChanged += new System.EventHandler(this.Check_Box_Engine_CheckedChanged);
            // 
            // checkBoxFilter
            // 
            this.checkBoxFilter.AutoSize = true;
            this.checkBoxFilter.Location = new System.Drawing.Point(140, 351);
            this.checkBoxFilter.Name = "checkBoxFilter";
            this.checkBoxFilter.Size = new System.Drawing.Size(103, 17);
            this.checkBoxFilter.TabIndex = 9;
            this.checkBoxFilter.Text = "Air Filter Change";
            this.toolTip1.SetToolTip(this.checkBoxFilter, "select if your vehicle had an air filter change");
            this.checkBoxFilter.UseVisualStyleBackColor = true;
            this.checkBoxFilter.CheckedChanged += new System.EventHandler(this.checkBoxFilter_CheckedChanged);
            // 
            // checkBoxTransmission
            // 
            this.checkBoxTransmission.AutoSize = true;
            this.checkBoxTransmission.Location = new System.Drawing.Point(140, 328);
            this.checkBoxTransmission.Name = "checkBoxTransmission";
            this.checkBoxTransmission.Size = new System.Drawing.Size(142, 17);
            this.checkBoxTransmission.TabIndex = 8;
            this.checkBoxTransmission.Text = "Transmission Oil Change";
            this.toolTip1.SetToolTip(this.checkBoxTransmission, "Select if your vehicle had a transmission oil change");
            this.checkBoxTransmission.UseVisualStyleBackColor = true;
            this.checkBoxTransmission.CheckedChanged += new System.EventHandler(this.checkBoxTransmission_CheckedChanged);
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(61, 449);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(85, 23);
            this.btnAdd.TabIndex = 10;
            this.btnAdd.Text = "Add";
            this.toolTip1.SetToolTip(this.btnAdd, "Adds the inputted information to the list");
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnNew
            // 
            this.btnNew.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnNew.Location = new System.Drawing.Point(152, 449);
            this.btnNew.Name = "btnNew";
            this.btnNew.Size = new System.Drawing.Size(85, 23);
            this.btnNew.TabIndex = 11;
            this.btnNew.Text = "New";
            this.toolTip1.SetToolTip(this.btnNew, "resets the input fields");
            this.btnNew.UseVisualStyleBackColor = true;
            this.btnNew.Click += new System.EventHandler(this.btnNew_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(243, 449);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(85, 23);
            this.btnUpdate.TabIndex = 12;
            this.btnUpdate.Text = "Update";
            this.toolTip1.SetToolTip(this.btnUpdate, "Updates the Selected Item in the List");
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnRemove
            // 
            this.btnRemove.Location = new System.Drawing.Point(334, 449);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(85, 23);
            this.btnRemove.TabIndex = 13;
            this.btnRemove.Text = "Remove";
            this.toolTip1.SetToolTip(this.btnRemove, "Removes the Selected Item in the List");
            this.btnRemove.UseVisualStyleBackColor = true;
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // btnRemoveAll
            // 
            this.btnRemoveAll.Location = new System.Drawing.Point(425, 449);
            this.btnRemoveAll.Name = "btnRemoveAll";
            this.btnRemoveAll.Size = new System.Drawing.Size(85, 23);
            this.btnRemoveAll.TabIndex = 14;
            this.btnRemoveAll.Text = "RemoveAll";
            this.toolTip1.SetToolTip(this.btnRemoveAll, "removes all Items in the List");
            this.btnRemoveAll.UseVisualStyleBackColor = true;
            this.btnRemoveAll.Click += new System.EventHandler(this.btnRemoveAll_Click);
            // 
            // btnExit
            // 
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.Location = new System.Drawing.Point(516, 449);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(85, 23);
            this.btnExit.TabIndex = 15;
            this.btnExit.Text = "Exit";
            this.toolTip1.SetToolTip(this.btnExit, "Exits the program");
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(331, 29);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(108, 13);
            this.label12.TabIndex = 28;
            this.label12.Text = "Car Service Summary";
            // 
            // listView1
            // 
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.ColNum,
            this.ColFirstName,
            this.ColLastName,
            this.ColPhone,
            this.ColMake,
            this.ColModel,
            this.ColYear,
            this.ColColour,
            this.ColEngine,
            this.ColTransmission,
            this.ColFilter,
            this.ColCost});
            this.listView1.FullRowSelect = true;
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(335, 56);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(554, 176);
            this.listView1.TabIndex = 29;
            this.toolTip1.SetToolTip(this.listView1, "displays all items serviced");
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            this.listView1.SelectedIndexChanged += new System.EventHandler(this.listView1_SelectedIndexChanged);
            // 
            // ColNum
            // 
            this.ColNum.Text = "NO";
            // 
            // ColFirstName
            // 
            this.ColFirstName.Text = "FirstName";
            // 
            // ColLastName
            // 
            this.ColLastName.Text = "LastName";
            // 
            // ColPhone
            // 
            this.ColPhone.Text = "Phone";
            // 
            // ColMake
            // 
            this.ColMake.Text = "Make";
            // 
            // ColModel
            // 
            this.ColModel.Text = "Model";
            // 
            // ColYear
            // 
            this.ColYear.Text = "Year";
            // 
            // ColColour
            // 
            this.ColColour.Text = "Colour";
            // 
            // ColEngine
            // 
            this.ColEngine.Text = "Engine Oil Change";
            // 
            // ColTransmission
            // 
            this.ColTransmission.Text = "Transmission Oil Change";
            // 
            // ColFilter
            // 
            this.ColFilter.Text = "Air Filter Change";
            // 
            // ColCost
            // 
            this.ColCost.Text = "Cost";
            // 
            // comboBoxYear
            // 
            this.comboBoxYear.FormattingEnabled = true;
            this.comboBoxYear.Location = new System.Drawing.Point(140, 241);
            this.comboBoxYear.Name = "comboBoxYear";
            this.comboBoxYear.Size = new System.Drawing.Size(121, 21);
            this.comboBoxYear.TabIndex = 5;
            this.toolTip1.SetToolTip(this.comboBoxYear, "Select the Year your vehicle was made");
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(123, 377);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(13, 13);
            this.label13.TabIndex = 30;
            this.label13.Text = "$";
            // 
            // Form1
            // 
            this.AcceptButton = this.btnAdd;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnNew;
            this.ClientSize = new System.Drawing.Size(971, 489);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnRemoveAll);
            this.Controls.Add(this.btnRemove);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnNew);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.checkBoxTransmission);
            this.Controls.Add(this.checkBoxFilter);
            this.Controls.Add(this.Check_Box_Engine);
            this.Controls.Add(this.txtBoxCost);
            this.Controls.Add(this.comboBoxYear);
            this.Controls.Add(this.comboBoxMake);
            this.Controls.Add(this.txtBoxLastName);
            this.Controls.Add(this.txtBoxPhone);
            this.Controls.Add(this.txtBoxColour);
            this.Controls.Add(this.txtBoxModel);
            this.Controls.Add(this.txtBoxFirstName);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Car Service Shop";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtBoxFirstName;
        private System.Windows.Forms.TextBox txtBoxModel;
        private System.Windows.Forms.TextBox txtBoxColour;
        private System.Windows.Forms.TextBox txtBoxPhone;
        private System.Windows.Forms.TextBox txtBoxLastName;
        private System.Windows.Forms.ComboBox comboBoxMake;
        private System.Windows.Forms.TextBox txtBoxCost;
        private System.Windows.Forms.CheckBox Check_Box_Engine;
        private System.Windows.Forms.CheckBox checkBoxFilter;
        private System.Windows.Forms.CheckBox checkBoxTransmission;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnNew;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnRemove;
        private System.Windows.Forms.Button btnRemoveAll;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader ColNum;
        private System.Windows.Forms.ColumnHeader ColFirstName;
        private System.Windows.Forms.ColumnHeader ColLastName;
        private System.Windows.Forms.ColumnHeader ColPhone;
        private System.Windows.Forms.ColumnHeader ColMake;
        private System.Windows.Forms.ColumnHeader ColModel;
        private System.Windows.Forms.ColumnHeader ColYear;
        private System.Windows.Forms.ColumnHeader ColColour;
        private System.Windows.Forms.ColumnHeader ColEngine;
        private System.Windows.Forms.ColumnHeader ColTransmission;
        private System.Windows.Forms.ColumnHeader ColFilter;
        private System.Windows.Forms.ColumnHeader ColCost;
        private System.Windows.Forms.ComboBox comboBoxYear;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}

