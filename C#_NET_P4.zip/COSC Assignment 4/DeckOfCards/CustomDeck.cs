﻿/*
 * Cam Davies
 * 8/11/2024
 * Custom Deck Class: Inherits Deck Class
 */


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeckOfCards
{
    internal class CustomDeck: Deck
    {
        // Default Constructor
        public CustomDeck() :base() { }
    }
}
