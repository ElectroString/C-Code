﻿/*
 * Cam Davies
 * 8/11/2024
 * Standard Deck Class: Inherits Deck Class
 */


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeckOfCards
{
    internal class StandardDeck : Deck
    {
        // Default constructor, calls
        public StandardDeck(): base() {
           
        }
    }
}
