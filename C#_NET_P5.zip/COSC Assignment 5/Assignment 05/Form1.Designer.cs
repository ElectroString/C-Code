﻿namespace Assignment_05
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cmboBox_grade = new System.Windows.Forms.ComboBox();
            this.cmboBox_testScore = new System.Windows.Forms.ComboBox();
            this.txtBox_email = new System.Windows.Forms.TextBox();
            this.txtBox_SIN = new System.Windows.Forms.TextBox();
            this.txtBox_lastName = new System.Windows.Forms.TextBox();
            this.txtBox_firstName = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_check = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lbl_totalCost = new System.Windows.Forms.Label();
            this.lbl_studyPeriod = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.cmboBox_programs = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.cmboBox_location = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.btn_register = new System.Windows.Forms.Button();
            this.btn_delete = new System.Windows.Forms.Button();
            this.btn_update = new System.Windows.Forms.Button();
            this.btn_removeAllRecords = new System.Windows.Forms.Button();
            this.btnLoadRecords = new System.Windows.Forms.Button();
            this.btn_exit = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.cmboBox_SIN = new System.Windows.Forms.ComboBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.registerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.recordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.updateRecordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteRecordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteAllRecordsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loadRecordsToServerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.readHelpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.technicalSupportsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutDCRegistrationAppToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(42, 321);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(845, 172);
            this.dataGridView1.TabIndex = 0;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cmboBox_grade);
            this.groupBox1.Controls.Add(this.cmboBox_testScore);
            this.groupBox1.Controls.Add(this.txtBox_email);
            this.groupBox1.Controls.Add(this.txtBox_SIN);
            this.groupBox1.Controls.Add(this.txtBox_lastName);
            this.groupBox1.Controls.Add(this.txtBox_firstName);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(42, 27);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(845, 120);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Student Information";
            // 
            // cmboBox_grade
            // 
            this.cmboBox_grade.FormattingEnabled = true;
            this.cmboBox_grade.Location = new System.Drawing.Point(633, 70);
            this.cmboBox_grade.Name = "cmboBox_grade";
            this.cmboBox_grade.Size = new System.Drawing.Size(135, 21);
            this.cmboBox_grade.TabIndex = 11;
            // 
            // cmboBox_testScore
            // 
            this.cmboBox_testScore.FormattingEnabled = true;
            this.cmboBox_testScore.Location = new System.Drawing.Point(633, 30);
            this.cmboBox_testScore.Name = "cmboBox_testScore";
            this.cmboBox_testScore.Size = new System.Drawing.Size(135, 21);
            this.cmboBox_testScore.TabIndex = 10;
            // 
            // txtBox_email
            // 
            this.txtBox_email.Location = new System.Drawing.Point(284, 70);
            this.txtBox_email.Name = "txtBox_email";
            this.txtBox_email.Size = new System.Drawing.Size(191, 20);
            this.txtBox_email.TabIndex = 9;
            // 
            // txtBox_SIN
            // 
            this.txtBox_SIN.Location = new System.Drawing.Point(284, 30);
            this.txtBox_SIN.Name = "txtBox_SIN";
            this.txtBox_SIN.Size = new System.Drawing.Size(191, 20);
            this.txtBox_SIN.TabIndex = 8;
            // 
            // txtBox_lastName
            // 
            this.txtBox_lastName.Location = new System.Drawing.Point(106, 70);
            this.txtBox_lastName.Name = "txtBox_lastName";
            this.txtBox_lastName.Size = new System.Drawing.Size(141, 20);
            this.txtBox_lastName.TabIndex = 7;
            // 
            // txtBox_firstName
            // 
            this.txtBox_firstName.Location = new System.Drawing.Point(106, 30);
            this.txtBox_firstName.Name = "txtBox_firstName";
            this.txtBox_firstName.Size = new System.Drawing.Size(141, 20);
            this.txtBox_firstName.TabIndex = 6;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(517, 70);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(97, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "High School Grade";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(517, 30);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(109, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Admission Test Score";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(253, 70);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(32, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Email";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(253, 30);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(25, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "SIN";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(42, 70);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Last Name";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(42, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "First Name";
            // 
            // btn_check
            // 
            this.btn_check.Location = new System.Drawing.Point(42, 154);
            this.btn_check.Name = "btn_check";
            this.btn_check.Size = new System.Drawing.Size(110, 31);
            this.btn_check.TabIndex = 2;
            this.btn_check.Text = "&Check";
            this.btn_check.UseVisualStyleBackColor = true;
            this.btn_check.Click += new System.EventHandler(this.btn_check_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lbl_totalCost);
            this.groupBox2.Controls.Add(this.lbl_studyPeriod);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.cmboBox_programs);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.cmboBox_location);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Location = new System.Drawing.Point(42, 192);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(845, 73);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Available Programs";
            // 
            // lbl_totalCost
            // 
            this.lbl_totalCost.AutoSize = true;
            this.lbl_totalCost.Location = new System.Drawing.Point(740, 43);
            this.lbl_totalCost.Name = "lbl_totalCost";
            this.lbl_totalCost.Size = new System.Drawing.Size(28, 13);
            this.lbl_totalCost.TabIndex = 18;
            this.lbl_totalCost.Text = "0.0$";
            // 
            // lbl_studyPeriod
            // 
            this.lbl_studyPeriod.AutoSize = true;
            this.lbl_studyPeriod.Location = new System.Drawing.Point(655, 43);
            this.lbl_studyPeriod.Name = "lbl_studyPeriod";
            this.lbl_studyPeriod.Size = new System.Drawing.Size(13, 13);
            this.lbl_studyPeriod.TabIndex = 17;
            this.lbl_studyPeriod.Text = "0";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(725, 26);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(55, 13);
            this.label10.TabIndex = 16;
            this.label10.Text = "Total Cost";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(630, 26);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(67, 13);
            this.label9.TabIndex = 15;
            this.label9.Text = "Study Period";
            // 
            // cmboBox_programs
            // 
            this.cmboBox_programs.Enabled = false;
            this.cmboBox_programs.FormattingEnabled = true;
            this.cmboBox_programs.Location = new System.Drawing.Point(411, 35);
            this.cmboBox_programs.Name = "cmboBox_programs";
            this.cmboBox_programs.Size = new System.Drawing.Size(148, 21);
            this.cmboBox_programs.TabIndex = 14;
            this.cmboBox_programs.SelectedIndexChanged += new System.EventHandler(this.cmboBox_programs_SelectedIndexChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(354, 38);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(51, 13);
            this.label8.TabIndex = 13;
            this.label8.Text = "Programs";
            // 
            // cmboBox_location
            // 
            this.cmboBox_location.Enabled = false;
            this.cmboBox_location.FormattingEnabled = true;
            this.cmboBox_location.Location = new System.Drawing.Point(137, 35);
            this.cmboBox_location.Name = "cmboBox_location";
            this.cmboBox_location.Size = new System.Drawing.Size(148, 21);
            this.cmboBox_location.TabIndex = 12;
            this.cmboBox_location.SelectedIndexChanged += new System.EventHandler(this.cmboBox_location_SelectedIndexChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(42, 38);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(89, 13);
            this.label7.TabIndex = 0;
            this.label7.Text = "Campus Location";
            // 
            // btn_register
            // 
            this.btn_register.Location = new System.Drawing.Point(42, 271);
            this.btn_register.Name = "btn_register";
            this.btn_register.Size = new System.Drawing.Size(110, 34);
            this.btn_register.TabIndex = 4;
            this.btn_register.Text = "Register &Student";
            this.btn_register.UseVisualStyleBackColor = true;
            this.btn_register.Click += new System.EventHandler(this.btn_register_Click);
            // 
            // btn_delete
            // 
            this.btn_delete.Location = new System.Drawing.Point(42, 508);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(110, 34);
            this.btn_delete.TabIndex = 5;
            this.btn_delete.Text = "&Delete Record";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // btn_update
            // 
            this.btn_update.Location = new System.Drawing.Point(158, 508);
            this.btn_update.Name = "btn_update";
            this.btn_update.Size = new System.Drawing.Size(110, 34);
            this.btn_update.TabIndex = 6;
            this.btn_update.Text = "&Update Record";
            this.btn_update.UseVisualStyleBackColor = true;
            this.btn_update.Click += new System.EventHandler(this.btn_update_Click);
            // 
            // btn_removeAllRecords
            // 
            this.btn_removeAllRecords.Location = new System.Drawing.Point(432, 508);
            this.btn_removeAllRecords.Name = "btn_removeAllRecords";
            this.btn_removeAllRecords.Size = new System.Drawing.Size(131, 34);
            this.btn_removeAllRecords.TabIndex = 7;
            this.btn_removeAllRecords.Text = "&Remove All Records";
            this.btn_removeAllRecords.UseVisualStyleBackColor = true;
            this.btn_removeAllRecords.Click += new System.EventHandler(this.btn_removeAllRecords_Click);
            // 
            // btnLoadRecords
            // 
            this.btnLoadRecords.Location = new System.Drawing.Point(569, 508);
            this.btnLoadRecords.Name = "btnLoadRecords";
            this.btnLoadRecords.Size = new System.Drawing.Size(141, 34);
            this.btnLoadRecords.TabIndex = 8;
            this.btnLoadRecords.Text = "&Load Records to Server";
            this.btnLoadRecords.UseVisualStyleBackColor = true;
            this.btnLoadRecords.Click += new System.EventHandler(this.btnLoadRecords_Click);
            // 
            // btn_exit
            // 
            this.btn_exit.Location = new System.Drawing.Point(770, 508);
            this.btn_exit.Name = "btn_exit";
            this.btn_exit.Size = new System.Drawing.Size(110, 34);
            this.btn_exit.TabIndex = 9;
            this.btn_exit.Text = "&Exit";
            this.btn_exit.UseVisualStyleBackColor = true;
            this.btn_exit.Click += new System.EventHandler(this.btn_exit_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(42, 582);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(25, 13);
            this.label11.TabIndex = 10;
            this.label11.Text = "SIN";
            // 
            // cmboBox_SIN
            // 
            this.cmboBox_SIN.FormattingEnabled = true;
            this.cmboBox_SIN.Location = new System.Drawing.Point(73, 579);
            this.cmboBox_SIN.Name = "cmboBox_SIN";
            this.cmboBox_SIN.Size = new System.Drawing.Size(195, 21);
            this.cmboBox_SIN.TabIndex = 11;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(939, 24);
            this.menuStrip1.TabIndex = 12;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.registerToolStripMenuItem,
            this.recordToolStripMenuItem,
            this.deleteAllRecordsToolStripMenuItem,
            this.loadRecordsToServerToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // registerToolStripMenuItem
            // 
            this.registerToolStripMenuItem.Name = "registerToolStripMenuItem";
            this.registerToolStripMenuItem.Size = new System.Drawing.Size(194, 22);
            this.registerToolStripMenuItem.Text = "Register";
            this.registerToolStripMenuItem.Click += new System.EventHandler(this.registerToolStripMenuItem_Click);
            // 
            // recordToolStripMenuItem
            // 
            this.recordToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.updateRecordToolStripMenuItem,
            this.deleteRecordToolStripMenuItem});
            this.recordToolStripMenuItem.Name = "recordToolStripMenuItem";
            this.recordToolStripMenuItem.Size = new System.Drawing.Size(194, 22);
            this.recordToolStripMenuItem.Text = "Record";
            // 
            // updateRecordToolStripMenuItem
            // 
            this.updateRecordToolStripMenuItem.Name = "updateRecordToolStripMenuItem";
            this.updateRecordToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.updateRecordToolStripMenuItem.Text = "Update Record";
            this.updateRecordToolStripMenuItem.Click += new System.EventHandler(this.updateRecordToolStripMenuItem_Click);
            // 
            // deleteRecordToolStripMenuItem
            // 
            this.deleteRecordToolStripMenuItem.Name = "deleteRecordToolStripMenuItem";
            this.deleteRecordToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.deleteRecordToolStripMenuItem.Text = "Delete Record";
            this.deleteRecordToolStripMenuItem.Click += new System.EventHandler(this.deleteRecordToolStripMenuItem_Click);
            // 
            // deleteAllRecordsToolStripMenuItem
            // 
            this.deleteAllRecordsToolStripMenuItem.Name = "deleteAllRecordsToolStripMenuItem";
            this.deleteAllRecordsToolStripMenuItem.Size = new System.Drawing.Size(194, 22);
            this.deleteAllRecordsToolStripMenuItem.Text = "Delete All Records";
            this.deleteAllRecordsToolStripMenuItem.Click += new System.EventHandler(this.deleteAllRecordsToolStripMenuItem_Click);
            // 
            // loadRecordsToServerToolStripMenuItem
            // 
            this.loadRecordsToServerToolStripMenuItem.Name = "loadRecordsToServerToolStripMenuItem";
            this.loadRecordsToServerToolStripMenuItem.Size = new System.Drawing.Size(194, 22);
            this.loadRecordsToServerToolStripMenuItem.Text = "Load Records to Server";
            this.loadRecordsToServerToolStripMenuItem.Click += new System.EventHandler(this.loadRecordsToServerToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(194, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.readHelpToolStripMenuItem,
            this.technicalSupportsToolStripMenuItem,
            this.aboutDCRegistrationAppToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // readHelpToolStripMenuItem
            // 
            this.readHelpToolStripMenuItem.Name = "readHelpToolStripMenuItem";
            this.readHelpToolStripMenuItem.Size = new System.Drawing.Size(219, 22);
            this.readHelpToolStripMenuItem.Text = "Read Help";
            this.readHelpToolStripMenuItem.Click += new System.EventHandler(this.readHelpToolStripMenuItem_Click);
            // 
            // technicalSupportsToolStripMenuItem
            // 
            this.technicalSupportsToolStripMenuItem.Name = "technicalSupportsToolStripMenuItem";
            this.technicalSupportsToolStripMenuItem.Size = new System.Drawing.Size(219, 22);
            this.technicalSupportsToolStripMenuItem.Text = "Technical Supports";
            this.technicalSupportsToolStripMenuItem.Click += new System.EventHandler(this.technicalSupportsToolStripMenuItem_Click);
            // 
            // aboutDCRegistrationAppToolStripMenuItem
            // 
            this.aboutDCRegistrationAppToolStripMenuItem.Name = "aboutDCRegistrationAppToolStripMenuItem";
            this.aboutDCRegistrationAppToolStripMenuItem.Size = new System.Drawing.Size(219, 22);
            this.aboutDCRegistrationAppToolStripMenuItem.Text = "About DC-Registration App";
            this.aboutDCRegistrationAppToolStripMenuItem.Click += new System.EventHandler(this.aboutDCRegistrationAppToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(939, 640);
            this.Controls.Add(this.cmboBox_SIN);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.btn_exit);
            this.Controls.Add(this.btnLoadRecords);
            this.Controls.Add(this.btn_removeAllRecords);
            this.Controls.Add(this.btn_update);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.btn_register);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.btn_check);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "DC Registration App";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox cmboBox_grade;
        private System.Windows.Forms.ComboBox cmboBox_testScore;
        private System.Windows.Forms.TextBox txtBox_email;
        private System.Windows.Forms.TextBox txtBox_SIN;
        private System.Windows.Forms.TextBox txtBox_lastName;
        private System.Windows.Forms.TextBox txtBox_firstName;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_check;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label lbl_totalCost;
        private System.Windows.Forms.Label lbl_studyPeriod;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox cmboBox_programs;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cmboBox_location;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btn_register;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.Button btn_update;
        private System.Windows.Forms.Button btn_removeAllRecords;
        private System.Windows.Forms.Button btnLoadRecords;
        private System.Windows.Forms.Button btn_exit;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox cmboBox_SIN;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem registerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem recordToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem updateRecordToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteRecordToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteAllRecordsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loadRecordsToServerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem readHelpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem technicalSupportsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutDCRegistrationAppToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
    }
}

